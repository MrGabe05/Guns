package com.gabrielhd.guns.Guns;

import org.bukkit.inventory.ItemStack;

public class Ammo {

    private final String name;
    private ItemStack ammoItem;

    public Ammo(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ItemStack getAmmoItem() {
        return ammoItem;
    }

    public void setAmmoItem(ItemStack ammoItem) {
        this.ammoItem = ammoItem;
    }
}
