package com.gabrielhd.guns.Guns;

import com.gabrielhd.guns.Enums.ExplosiveType;
import com.gabrielhd.guns.Utils.NBTItem;
import com.google.common.collect.Lists;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class Explosive {

    private final String name;
    private String permission;
    private ItemStack explosiveItem;
    private ExplosiveType explosiveType;
    private boolean usePermission;
    private long explosionDelay;
    private int shootDelay;
    private int velocity;
    private double radius;

    private final Map<UUID, Long> shootDelayList = new HashMap<>();
    private final List<Material> blockToBreak = Lists.newArrayList();

    public Explosive(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public ItemStack getExplosiveItem() {
        return explosiveItem;
    }

    public void setExplosiveItem(ItemStack explosiveItem) {
        this.explosiveItem = explosiveItem;
    }

    public ExplosiveType getExplosiveType() {
        return explosiveType;
    }

    public void setExplosiveType(ExplosiveType explosiveType) {
        this.explosiveType = explosiveType;
    }

    public boolean isUsePermission() {
        return usePermission;
    }

    public void setUsePermission(boolean usePermission) {
        this.usePermission = usePermission;
    }

    public int getShootDelay() {
        return shootDelay;
    }

    public void setShootDelay(int shootDelay) {
        this.shootDelay = shootDelay;
    }

    public int getVelocity() {
        return velocity;
    }

    public void setVelocity(int velocity) {
        this.velocity = velocity;
    }

    public long getExplosionDelay() {
        return explosionDelay;
    }

    public void setExplosionDelay(long explosionDelay) {
        this.explosionDelay = explosionDelay;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public Map<UUID, Long> getShootDelayList() {
        return shootDelayList;
    }

    public List<Material> getBlockToBreak() {
        return blockToBreak;
    }

    public void giveExplosive(Player player) {
        NBTItem nbtItem = new NBTItem(this.explosiveItem);
        nbtItem.setBoolean("Explosive", true);
        nbtItem.setString("ExplosiveType", this.name);

        player.getInventory().addItem(nbtItem.getItem());
    }
}
