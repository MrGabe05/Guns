package com.gabrielhd.guns.Guns;

import com.gabrielhd.guns.Enums.DiscountType;
import com.gabrielhd.guns.Utils.NBTItem;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Armor {

    private final String name;
    private ItemStack helmet;
    private ItemStack chestplate;
    private ItemStack leggings;
    private ItemStack boots;
    private DiscountType discountType;
    private double protection;
    private int durability;

    public Armor(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public DiscountType getDiscountType() {
        return discountType;
    }

    public void setDiscountType(DiscountType discountType) {
        this.discountType = discountType;
    }

    public ItemStack getHelmet() {
        return helmet;
    }

    public void setHelmet(ItemStack helmet) {
        this.helmet = helmet;
    }

    public void giveHelmet(Player player) {
        player.getInventory().addItem(this.helmet);
    }

    public ItemStack getChestplate() {
        return chestplate;
    }

    public void setChestplate(ItemStack chestplate) {
        this.chestplate = chestplate;
    }

    public void giveChestplate(Player player) {
        NBTItem nbtItem = new NBTItem(this.chestplate);
        nbtItem.setBoolean("CustomArmor", true);
        nbtItem.setString("Armor", this.name);
        nbtItem.setInteger("Durability", this.durability);
        nbtItem.setDouble("Protection", this.protection);

        player.getInventory().addItem(nbtItem.getItem());
    }

    public ItemStack getLeggings() {
        return leggings;
    }

    public void setLeggings(ItemStack leggings) {
        this.leggings = leggings;
    }

    public void giveLeggings(Player player) {
        NBTItem nbtItem = new NBTItem(this.leggings);
        nbtItem.setBoolean("CustomArmor", true);
        nbtItem.setString("Armor", this.name);
        nbtItem.setInteger("Durability", this.durability);
        nbtItem.setDouble("Protection", this.protection);

        player.getInventory().addItem(nbtItem.getItem());
    }

    public ItemStack getBoots() {
        return boots;
    }

    public void setBoots(ItemStack boots) {
        this.boots = boots;
    }

    public void giveBoots(Player player) {
        NBTItem nbtItem = new NBTItem(this.boots);
        nbtItem.setBoolean("CustomArmor", true);
        nbtItem.setString("Armor", this.name);
        nbtItem.setInteger("Durability", this.durability);
        nbtItem.setDouble("Protection", this.protection);

        player.getInventory().addItem(nbtItem.getItem());
    }
}
