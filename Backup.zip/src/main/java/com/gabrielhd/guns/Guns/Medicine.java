package com.gabrielhd.guns.Guns;

import com.gabrielhd.guns.Utils.NBTItem;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class Medicine {

    private final String name;
    private ItemStack itemMed;
    private double health;

    public Medicine(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public ItemStack getItemMed() {
        return itemMed;
    }

    public void setItemMed(ItemStack itemMed) {
        this.itemMed = itemMed;
    }

    public double getHealth() {
        return health;
    }

    public void setHealth(double health) {
        this.health = health;
    }

    public void giveMedicine(Player player) {
        NBTItem nbtItem = new NBTItem(this.itemMed);
        nbtItem.setBoolean("Medicine", true);
        nbtItem.setString("MedicineType", this.name);

        player.getInventory().addItem(nbtItem.getItem());
    }
}
