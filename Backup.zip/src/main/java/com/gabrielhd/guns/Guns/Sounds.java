package com.gabrielhd.guns.Guns;

import org.bukkit.Sound;

public class Sounds {

    private Sound sound;
    private float volume;

    public Sounds() {
    }

    public Sound getSound() {
        return sound;
    }

    public void setSound(Sound sound) {
        this.sound = sound;
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float volume) {
        this.volume = volume;
    }
}
