package com.gabrielhd.guns.Guns;

import com.gabrielhd.guns.Enums.FireType;
import com.gabrielhd.guns.Enums.GunType;
import com.gabrielhd.guns.Utils.NBTItem;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Guns {

    private final String name;
    private String permission;
    private ItemStack gunItem;
    private Ammo ammo;
    private GunType gunType;
    private FireType fireType;
    private Sounds shootingSound;
    private Sounds reloadingSound;
    private Sounds noBulletsSound;
    private boolean automaticReload;
    private boolean usePermission;
    private boolean bounce;
    private double normalDamage;
    private double headshotDamage;
    private double recoil;
    private int projectileAmount;
    private int reloadDelay;
    private int shootDelay;
    private int ammoCapacity;
    private int zoomLevel;
    private int velocity;

    private final Map<UUID, Long> shootDelayList = new HashMap<>();
    
    public Guns(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public String getPermission() {
        return permission;
    }

    public void setPermission(String permission) {
        this.permission = permission;
    }

    public ItemStack getGunItem() {
        return gunItem;
    }

    public void setGunItem(ItemStack gunItem) {
        this.gunItem = gunItem;
    }

    public Ammo getAmmo() {
        return this.ammo;
    }

    public void setAmmo(Ammo ammo) {
        this.ammo = ammo;
    }

    public GunType getGunType() {
        return gunType;
    }

    public void setGunType(GunType gunType) {
        this.gunType = gunType;
    }

    public FireType getFireType() {
        return fireType;
    }

    public void setFireType(FireType fireType) {
        this.fireType = fireType;
    }

    public boolean isAutomaticReload() {
        return automaticReload;
    }

    public void setAutomaticReload(boolean automaticReload) {
        this.automaticReload = automaticReload;
    }

    public boolean isUsePermission() {
        return usePermission;
    }

    public void setUsePermission(boolean usePermission) {
        this.usePermission = usePermission;
    }

    public boolean isBounce() {
        return bounce;
    }

    public void setBounce(boolean bounce) {
        this.bounce = bounce;
    }

    public double getNormalDamage() {
        return normalDamage;
    }

    public void setNormalDamage(double normalDamage) {
        this.normalDamage = normalDamage;
    }

    public double getHeadshotDamage() {
        return headshotDamage;
    }

    public void setHeadshotDamage(double headshotDamage) {
        this.headshotDamage = headshotDamage;
    }

    public double getRecoil() {
        return recoil;
    }

    public void setRecoil(double recoil) {
        this.recoil = recoil;
    }

    public int getReloadDelay() {
        return reloadDelay;
    }

    public void setReloadDelay(int reloadDelay) {
        this.reloadDelay = reloadDelay;
    }

    public int getShootDelay() {
        return shootDelay;
    }

    public void setShootDelay(int shootDelay) {
        this.shootDelay = shootDelay;
    }

    public int getAmmoCapacity() {
        return ammoCapacity;
    }

    public void setAmmoCapacity(int ammoCapacity) {
        this.ammoCapacity = ammoCapacity;
    }

    public int getZoomLevel() {
        return zoomLevel;
    }

    public void setZoomLevel(int zoomLevel) {
        this.zoomLevel = zoomLevel;
    }

    public int getVelocity() {
        return velocity;
    }

    public void setVelocity(int velocity) {
        this.velocity = velocity;
    }

    public int getProjectileAmount() {
        return projectileAmount;
    }

    public void setProjectileAmount(int projectileAmount) {
        this.projectileAmount = projectileAmount;
    }

    public Sounds getNoBulletsSound() {
        return noBulletsSound;
    }

    public void setNoBulletsSound(Sounds noBulletsSound) {
        this.noBulletsSound = noBulletsSound;
    }

    public Sounds getReloadingSound() {
        return reloadingSound;
    }

    public void setReloadingSound(Sounds reloadingSound) {
        this.reloadingSound = reloadingSound;
    }

    public Sounds getShootingSound() {
        return shootingSound;
    }

    public void setShootingSound(Sounds shootingSound) {
        this.shootingSound = shootingSound;
    }

    public Map<UUID, Long> getShootDelayList() {
        return shootDelayList;
    }

    public void giveGunItem(Player player) {
        NBTItem nbtItem = new NBTItem(this.gunItem);
        nbtItem.setBoolean("Weapon", true);
        nbtItem.setBoolean("Armed", true);
        nbtItem.setBoolean("Gun", true);
        nbtItem.setBoolean("Scope", false);
        nbtItem.setBoolean("Reloading", false);
        nbtItem.setString("WeaponType", this.name);
        nbtItem.setString("UUID", UUID.randomUUID().toString());
        nbtItem.setInteger("CurrentAmount", this.ammoCapacity);

        player.getInventory().addItem(nbtItem.getItem());
    }

    public void giveAmmoItem(Player player) {
        NBTItem nbtItem2 = new NBTItem(this.ammo.getAmmoItem());
        nbtItem2.setBoolean("Ammo", true);
        nbtItem2.setString("AmmoType", this.name);

        player.getInventory().addItem(nbtItem2.getItem());
    }
}
