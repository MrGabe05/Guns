package com.gabrielhd.guns.Commands;

import com.gabrielhd.guns.Guns.Armor;
import com.gabrielhd.guns.Guns.Explosive;
import com.gabrielhd.guns.Guns.Guns;
import com.gabrielhd.guns.Guns.Medicine;
import com.gabrielhd.guns.Main;
import com.gabrielhd.guns.Manager.ConfigManager;
import com.gabrielhd.guns.Utils.Utils;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Commands implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if((sender instanceof Player)) {
            Player player = (Player) sender;
            if(!player.hasPermission("guns.command.admin")) {
                player.sendMessage(Main.Color(ConfigManager.getSettings().getString("Messages.NoPermissions")));
                return true;
            }
            if(args.length == 0 || args.length >= 4) {
                player.sendMessage(Main.Color("&e/guns list"));
                player.sendMessage(Main.Color("&e/guns give [Weapon Name]"));
                player.sendMessage(Main.Color("&e/guns medicine [Medicine Name]"));
                player.sendMessage(Main.Color("&e/guns ammo [Weapon Name] [Amount]"));
                player.sendMessage(Main.Color("&e/guns armor [Armor Name] [Armor piece]"));
                player.sendMessage(Main.Color("&e/guns list [All/Weapons/Explosives/Armors/Medicines]"));
                return true;
            }
            if(args.length == 3) {
                if(args[0].equalsIgnoreCase("ammo")) {
                    String name = args[1];
                    Guns guns = Main.getWeaponManager().getGun(name);
                    if(guns != null && guns.getAmmo().getAmmoItem() != null) {
                        if(Utils.isInt(args[2])) {
                            int amount = Integer.parseInt(args[2]);
                            for (int i = 0; i < amount; i++) {
                                guns.giveAmmoItem(player);
                            }
                            player.sendMessage(Main.Color("&aYou were given "+amount+" ammo for the "+guns.getName()+" weapon"));
                            return true;
                        }
                        return true;
                    }

                    Explosive explosive = Main.getWeaponManager().getExplosive(name);
                    if(explosive != null && explosive.getExplosiveItem() != null) {
                        if(Utils.isInt(args[2])) {
                            int amount = Integer.parseInt(args[2]);
                            for (int i = 0; i < amount; i++) {
                                explosive.giveExplosive(player);
                            }
                            player.sendMessage(Main.Color("&aYou were given "+amount+" "+explosive.getName()+" explosive"));
                            return true;
                        }
                        return true;
                    }

                    player.sendMessage(Main.Color("&6Weapons: "));
                    for(Guns gunsList : Main.getWeaponManager().getGuns()) {
                        player.sendMessage(Main.Color("  &7- &e"+gunsList.getName()+" &7Ammo: &e"+(gunsList.getAmmo() == null ? "Unknown" : gunsList.getAmmo().getName())));
                    }
                    player.sendMessage(Main.Color("&6Explosives: "));
                    for(Explosive explosives : Main.getWeaponManager().getExplosives()) {
                        player.sendMessage(Main.Color("  &7- &e"+explosives.getName()));
                    }
                    return true;
                }
                if(args[0].equalsIgnoreCase("armor")) {
                    String name = args[1];
                    Armor armor = Main.getWeaponManager().getArmor(name);
                    if(armor != null) {
                        if (args[2].equalsIgnoreCase("helmet")) {
                            if (armor.getHelmet() != null) {
                                armor.giveHelmet(player);
                            }
                            player.sendMessage(Main.Color("&aYou were given the "+armor.getName()+" Helmet"));
                            return true;
                        }
                        if (args[2].equalsIgnoreCase("chestplate")) {
                            if (armor.getChestplate() != null) {
                                armor.giveChestplate(player);
                            }
                            player.sendMessage(Main.Color("&aYou were given the "+armor.getName()+" Chestplate"));
                            return true;
                        }
                        if (args[2].equalsIgnoreCase("leggings")) {
                            if (armor.getLeggings() != null) {
                                armor.giveLeggings(player);
                            }
                            player.sendMessage(Main.Color("&aYou were given the "+armor.getName()+" Leggings"));
                            return true;
                        }
                        if (args[2].equalsIgnoreCase("boots")) {
                            if (armor.getBoots() != null) {
                                armor.giveBoots(player);
                            }
                            player.sendMessage(Main.Color("&aYou were given the "+armor.getName()+" Boots"));
                            return true;
                        }
                        player.sendMessage(Main.Color("&eArmor pieces: Helmet, Chestplate, Leggings, Boots."));
                        return true;
                    }
                    return true;
                }
                player.sendMessage(Main.Color("&e/guns list"));
                player.sendMessage(Main.Color("&e/guns give [Weapon Name]"));
                player.sendMessage(Main.Color("&e/guns medicine [Medicine Name]"));
                player.sendMessage(Main.Color("&e/guns ammo [Weapon Name] [Amount]"));
                player.sendMessage(Main.Color("&e/guns armor [Armor Name] [Armor piece]"));
                player.sendMessage(Main.Color("&e/guns list [All/Weapons/Explosives/Armors/Medicines]"));
                return true;
            }
            if(args.length == 2) {
                if(args[0].equalsIgnoreCase("armor")) {
                    player.sendMessage(Main.Color("&eArmor pieces: Helmet, Chestplate, Leggings, Boots."));
                    return true;
                }
                if(args[0].equalsIgnoreCase("give")) {
                    String name = args[1];
                    Guns guns = Main.getWeaponManager().getGun(name);
                    if(guns != null && guns.getGunItem() != null) {
                        guns.giveGunItem(player);
                        player.sendMessage(Main.Color("&aYou were given the "+guns.getName()+" weapon"));
                        return true;
                    }
                    Explosive explosive = Main.getWeaponManager().getExplosive(name);
                    if(explosive != null && explosive.getExplosiveItem() != null) {
                        explosive.giveExplosive(player);
                        player.sendMessage(Main.Color("&aYou were given the "+explosive.getName()+" explosive"));
                        return true;
                    }
                    player.sendMessage(Main.Color("&6Weapons: "));
                    for(Guns gunsList : Main.getWeaponManager().getGuns()) {
                        player.sendMessage(Main.Color("  &7- &e"+gunsList.getName()+" &7Ammo: &e"+(gunsList.getAmmo() == null ? "Unknown" : gunsList.getAmmo().getName())));
                    }
                    player.sendMessage(Main.Color("&6Explosives: "));
                    for(Explosive explosives : Main.getWeaponManager().getExplosives()) {
                        player.sendMessage(Main.Color("  &7- &e"+explosives.getName()));
                    }
                    return true;
                }
                if(args[0].equalsIgnoreCase("medicine")) {
                    String name = args[1];
                    Medicine medicine = Main.getWeaponManager().getMedicine(name);
                    if(medicine != null && medicine.getItemMed() != null) {
                        medicine.giveMedicine(player);
                        player.sendMessage(Main.Color("&aYou were given the "+medicine.getName()+" medicine"));
                        return true;
                    }
                    player.sendMessage(Main.Color("&6Medicines: "));
                    for (Medicine medicines : Main.getWeaponManager().getMedicines()) {
                        player.sendMessage(Main.Color("  &7- &e" + medicines.getName()));
                    }
                    return true;
                }
                if(args[0].equalsIgnoreCase("list")) {
                    if (args[1].equalsIgnoreCase("all")) {
                        player.sendMessage(Main.Color("&6Weapons: "));
                        for (Guns guns : Main.getWeaponManager().getGuns()) {
                            player.sendMessage(Main.Color("  &7- &e" + guns.getName() + " &7Ammo: &e" + guns.getAmmo().getName()));
                        }
                        player.sendMessage(Main.Color("&6Explosives: "));
                        for (Explosive explosive : Main.getWeaponManager().getExplosives()) {
                            player.sendMessage(Main.Color("  &7- &e" + explosive.getName()));
                        }
                        player.sendMessage(Main.Color("&6Armors: "));
                        for (Armor armor : Main.getWeaponManager().getArmors()) {
                            player.sendMessage(Main.Color("  &7- &e" + armor.getName()));
                        }
                        player.sendMessage(Main.Color("&6Medicines: "));
                        for (Medicine medicine : Main.getWeaponManager().getMedicines()) {
                            player.sendMessage(Main.Color("  &7- &e" + medicine.getName()));
                        }
                        return true;
                    }
                    if (args[1].equalsIgnoreCase("weapons")) {
                        player.sendMessage(Main.Color("&6Weapons: "));
                        for (Guns guns : Main.getWeaponManager().getGuns()) {
                            player.sendMessage(Main.Color("  &7- &e" + guns.getName() + " &7Ammo: &e" + guns.getAmmo().getName()));
                        }
                        return true;
                    }
                    if (args[1].equalsIgnoreCase("explosives")) {
                        player.sendMessage(Main.Color("&6Explosives: "));
                        for (Explosive explosive : Main.getWeaponManager().getExplosives()) {
                            player.sendMessage(Main.Color("  &7- &e" + explosive.getName()));
                        }
                        return true;
                    }
                    if (args[1].equalsIgnoreCase("armors")) {
                        player.sendMessage(Main.Color("&6Armors: "));
                        for (Armor armor : Main.getWeaponManager().getArmors()) {
                            player.sendMessage(Main.Color("  &7- &e" + armor.getName()));
                        }
                        return true;
                    }
                    if (args[1].equalsIgnoreCase("medicines")) {
                        player.sendMessage(Main.Color("&6Medicines: "));
                        for (Medicine medicine : Main.getWeaponManager().getMedicines()) {
                            player.sendMessage(Main.Color("  &7- &e" + medicine.getName()));
                        }
                        return true;
                    }
                }
                player.sendMessage(Main.Color("&e/guns give [Weapon Name]"));
                player.sendMessage(Main.Color("&e/guns medicine [Medicine Name]"));
                player.sendMessage(Main.Color("&e/guns ammo [Weapon Name] [Amount]"));
                player.sendMessage(Main.Color("&e/guns armor [Armor Name] [Armor piece]"));
                player.sendMessage(Main.Color("&e/guns list [All/Weapons/Explosives/Armors/Medicines]"));
                return true;
            }
            if(args.length == 1) {
                if(args[0].equalsIgnoreCase("list") || args[0].equalsIgnoreCase("give")) {
                    player.sendMessage(Main.Color("&6Weapons: "));
                    for(Guns guns : Main.getWeaponManager().getGuns()) {
                        player.sendMessage(Main.Color("  &7- &e"+guns.getName()+" &7Ammo: &e"+(guns.getAmmo() == null ? "Unknown" : guns.getAmmo().getName())));
                    }
                    player.sendMessage(Main.Color("&6Explosives: "));
                    for(Explosive explosive : Main.getWeaponManager().getExplosives()) {
                        player.sendMessage(Main.Color("  &7- &e"+explosive.getName()));
                    }
                    if(args[0].equalsIgnoreCase("list")) {
                        player.sendMessage(Main.Color("&6Armors: "));
                        for(Armor armor : Main.getWeaponManager().getArmors()) {
                            player.sendMessage(Main.Color("  &7- &e"+armor.getName()));
                        }
                        player.sendMessage(Main.Color("&6Medicines: "));
                        for (Medicine medicine : Main.getWeaponManager().getMedicines()) {
                            player.sendMessage(Main.Color("  &7- &e" + medicine.getName()));
                        }
                        return true;
                    }
                    return true;
                }
                player.sendMessage(Main.Color("&e/guns give [Weapon Name]"));
                player.sendMessage(Main.Color("&e/guns medicine [Medicine Name]"));
                player.sendMessage(Main.Color("&e/guns ammo [Weapon Name] [Amount]"));
                player.sendMessage(Main.Color("&e/guns armor [Armor Name] [Armor piece]"));
                player.sendMessage(Main.Color("&e/guns list [All/Weapons/Explosives/Armors/Medicines]"));
                return true;
            }
        }
        return false;
    }
}
