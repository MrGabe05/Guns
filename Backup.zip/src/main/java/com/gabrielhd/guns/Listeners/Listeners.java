package com.gabrielhd.guns.Listeners;

import com.gabrielhd.guns.Enums.DiscountType;
import com.gabrielhd.guns.Enums.ExplosiveType;
import com.gabrielhd.guns.Enums.FireType;
import com.gabrielhd.guns.Enums.GunType;
import com.gabrielhd.guns.Guns.Armor;
import com.gabrielhd.guns.Guns.Explosive;
import com.gabrielhd.guns.Guns.Guns;
import com.gabrielhd.guns.Guns.Medicine;
import com.gabrielhd.guns.Main;
import com.gabrielhd.guns.Manager.ConfigManager;
import com.gabrielhd.guns.Utils.NBT.VersionMatcher;
import com.gabrielhd.guns.Utils.NBT.VersionWrapper;
import com.gabrielhd.guns.Utils.NBTItem;
import com.gabrielhd.guns.Utils.Utils;
import com.google.common.collect.Lists;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class Listeners implements Listener {

    private final VersionWrapper WRAPPER = new VersionMatcher().match();
    private final List<TNTPrimed> tnts = Lists.newArrayList();

    @EventHandler
    public void onInteractEvent(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = event.getItem();
        if(item != null && item.getType() != Material.AIR) {
            NBTItem nbtItem = new NBTItem(item);
            if(nbtItem.hasKey("Weapon") && nbtItem.getBoolean("Weapon") && nbtItem.hasKey("WeaponType")) {
                Guns guns = Main.getWeaponManager().getGun(nbtItem.getString("WeaponType"));
                if(guns != null) {
                    if(guns.isUsePermission() && !guns.getPermission().equalsIgnoreCase("") && !player.hasPermission(guns.getPermission())) {
                        player.sendMessage(Main.Color(ConfigManager.getSettings().getString("Messages.NoPermissions")));
                        event.setCancelled(true);
                        return;
                    }
                    if(guns.getFireType() == FireType.AUTOMATIC) {
                        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                            event.setCancelled(true);
                            if (player.isSneaking()) {
                                if (this.reloadGun(player, guns, nbtItem)) {
                                    Utils.sendActionbar(player, Main.Color(ConfigManager.getSettings().getString("Messages.ReloadingWeapon").replace("%weapon%", guns.getName())));
                                }
                                return;
                            }
                            if(guns.getShootDelayList().containsKey(player.getUniqueId()) && System.currentTimeMillis() - guns.getShootDelayList().get(player.getUniqueId()) < guns.getShootDelay()) {
                                event.setCancelled(true);
                                return;
                            }
                            if (this.shootGun(player, guns, nbtItem, guns.getFireType())) {
                                Utils.sendActionbar(player, Main.Color(ConfigManager.getSettings().getString("Messages.WeaponStatus").replace("%weapon%", guns.getName()).replace("%maxcapacity%", String.valueOf(guns.getAmmoCapacity())).replace("%currentamount%", String.valueOf(nbtItem.getInteger("CurrentAmount")))));
                            }
                            return;
                        }
                        if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
                            event.setCancelled(true);
                            if (nbtItem.getBoolean("Scope")) {
                                player.removePotionEffect(PotionEffectType.SLOW);
                                nbtItem.setBoolean("Scope", false);
                                player.setItemInHand(nbtItem.getItem());
                                return;
                            }
                            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000000, guns.getZoomLevel()));
                            nbtItem.setBoolean("Scope", true);
                            player.setItemInHand(nbtItem.getItem());
                        }
                        return;
                    }
                    if(guns.getFireType() == FireType.SEMIAUTOMATIC || guns.getFireType() == FireType.BURST) {
                        if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
                            event.setCancelled(true);
                            if (player.isSneaking()) {
                                this.reloadGun(player, guns, nbtItem);
                                return;
                            }
                            if(guns.getShootDelayList().containsKey(player.getUniqueId()) && System.currentTimeMillis() - guns.getShootDelayList().get(player.getUniqueId()) < guns.getShootDelay()) {
                                event.setCancelled(true);
                                return;
                            }
                            this.shootGun(player, guns, nbtItem, guns.getFireType());
                            return;
                        }
                        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
                            event.setCancelled(true);
                            if (nbtItem.getBoolean("Scope")) {
                                player.removePotionEffect(PotionEffectType.SLOW);
                                nbtItem.setBoolean("Scope", false);
                                player.setItemInHand(nbtItem.getItem());
                                return;
                            }
                            player.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 10000000, guns.getZoomLevel()));
                            nbtItem.setBoolean("Scope", true);
                            player.setItemInHand(nbtItem.getItem());
                            return;
                        }
                    }
                }
                return;
            }

            if(nbtItem.hasKey("Explosive") && nbtItem.getBoolean("Explosive") && nbtItem.hasKey("ExplosiveType")) {
                Explosive explosive = Main.getWeaponManager().getExplosive(nbtItem.getString("ExplosiveType"));
                if(explosive != null) {
                    if(explosive.isUsePermission() && !explosive.getPermission().equalsIgnoreCase("") && !player.hasPermission(explosive.getPermission())) {
                        player.sendMessage(Main.Color(ConfigManager.getSettings().getString("Messages.NoPermissions")));
                        event.setCancelled(true);
                        return;
                    }
                    if(explosive.getExplosiveType() == ExplosiveType.THROWING) {
                        if (event.getAction() == Action.LEFT_CLICK_AIR || event.getAction() == Action.LEFT_CLICK_BLOCK) {
                            event.setCancelled(true);
                            if(explosive.getShootDelayList().containsKey(player.getUniqueId()) && System.currentTimeMillis() - explosive.getShootDelayList().get(player.getUniqueId()) < explosive.getShootDelay()) {
                                event.setCancelled(true);
                                return;
                            }

                            Vector vector = player.getLocation().getDirection().multiply(explosive.getVelocity());
                            TNTPrimed tnt = player.getWorld().spawn(player.getLocation(), TNTPrimed.class);
                            tnt.setFuseTicks((int)TimeUnit.MILLISECONDS.toSeconds(explosive.getExplosionDelay()) * 20);
                            tnt.setVelocity(vector);

                            this.tnts.add(tnt);

                            if(item.getAmount() > 1) {
                                item.setAmount(item.getAmount()-1);
                            } else {
                                player.getInventory().remove(item);
                            }
                        }
                    }
                }
                return;
            }

            if(nbtItem.hasKey("Medicine") && nbtItem.getBoolean("Medicine") && nbtItem.hasKey("MedicineType")) {
                Medicine medicine = Main.getWeaponManager().getMedicine(nbtItem.getString("MedicineType"));
                if(medicine != null) {
                    if (Main.getCooldownPlayers().containsKey(player.getUniqueId()) && System.currentTimeMillis() - Main.getCooldownPlayers().get(player.getUniqueId()) < ConfigManager.getSettings().getLong("CooldownMeds")) {
                        int time = (int) TimeUnit.MILLISECONDS.toSeconds(ConfigManager.getSettings().getLong("CooldownMeds") - (System.currentTimeMillis() - Main.getCooldownPlayers().get(player.getUniqueId())));
                        player.sendMessage(Main.Color(ConfigManager.getSettings().getString("Messages.InCooldown").replace("%time%", String.valueOf(time))));
                        return;
                    }
                    if(player.getHealth() < player.getMaxHealth()) {
                        Main.getCooldownPlayers().remove(player.getUniqueId());
                        double newHealth = player.getHealth()+ medicine.getHealth();
                        if(newHealth > player.getMaxHealth()) {
                            newHealth = player.getMaxHealth();
                        }

                        player.setHealth(newHealth);
                        player.sendMessage(Main.Color(ConfigManager.getSettings().getString("Messages.MedicineUse").replace("%medicine%", medicine.getName()).replace("%health%", String.valueOf((medicine.getHealth()/2)))));

                        if(item.getAmount() > 1) {
                            item.setAmount(item.getAmount()-1);
                        } else {
                            player.getInventory().remove(item);
                        }
                        player.updateInventory();
                        Main.getCooldownPlayers().put(player.getUniqueId(), System.currentTimeMillis());
                    }
                }
            }
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlaceBlock(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getItemInHand();
        if(item != null && item.getType() != Material.AIR && !event.isCancelled()) {
            NBTItem nbtItem = new NBTItem(item);
            if(nbtItem.hasKey("Explosive") && nbtItem.getBoolean("Explosive") && nbtItem.hasKey("ExplosiveType")) {
                Explosive explosive = Main.getWeaponManager().getExplosive(nbtItem.getString("ExplosiveType"));
                if(explosive != null) {
                    if(explosive.isUsePermission() && !explosive.getPermission().equalsIgnoreCase("") && !player.hasPermission(explosive.getPermission())) {
                        player.sendMessage(Main.Color(ConfigManager.getSettings().getString("Messages.NoPermissions")));
                        return;
                    }
                    if(explosive.getExplosiveType() == ExplosiveType.STATIC) {
                        if(explosive.getShootDelayList().containsKey(player.getUniqueId()) && System.currentTimeMillis() - explosive.getShootDelayList().get(player.getUniqueId()) < explosive.getShootDelay()) {
                            event.setCancelled(true);
                            return;
                        }

                        Block block = event.getBlockPlaced();
                        if(block != null) {
                            block.setMetadata("Blocks", new FixedMetadataValue(Main.getInstance(), explosive));

                            Bukkit.getScheduler().runTaskLater(Main.getInstance(), () -> block.getWorld().createExplosion(block.getLocation(), (float)explosive.getRadius(), false), TimeUnit.MILLISECONDS.toSeconds(explosive.getExplosionDelay()) * 20L);
                        }
                    }
                }
            }
        }
    }

    public List<Block> getNearbyBlocks(Location location, int radius) {
        List<Block> blocks = new ArrayList<>();
        for(int x = location.getBlockX() - radius; x <= location.getBlockX() + radius; x++) {
            for(int y = location.getBlockY() - radius; y <= location.getBlockY() + radius; y++) {
                for (int z = location.getBlockZ() - radius; z <= location.getBlockZ() + radius; z++) {
                    blocks.add(location.getWorld().getBlockAt(x, y, z));
                }
            }
        }
        return blocks;
    }

    @EventHandler
    public void onBlockExplode(BlockExplodeEvent event) {
        Block block = event.getBlock();
        if(block.hasMetadata("Blocks")) {
            List<MetadataValue> value = block.getMetadata("Blocks");
            if(!value.isEmpty()) {
                Explosive explosive = (Explosive) value.get(0).value();
                if(explosive.getBlockToBreak().isEmpty()) {
                    event.blockList().clear();
                    return;
                }
                List<Block> blockToBreak = this.getNearbyBlocks(block.getLocation(), (int)explosive.getRadius()+2);
                event.blockList().removeIf(toBroken -> blockToBreak.contains(toBroken) && !explosive.getBlockToBreak().contains(toBroken.getType()));
                block.setType(Material.AIR);
            }
        }
    }

    @EventHandler
    public void onEntityExplode(EntityExplodeEvent event) {
        if(event.getEntity() instanceof TNTPrimed) {
            TNTPrimed tnt = (TNTPrimed) event.getEntity();
            if(this.tnts.contains(tnt)) {
                event.blockList().clear();
            }
        }

        Block block = event.getLocation().getBlock();
        if(block.hasMetadata("Blocks")) {
            List<MetadataValue> value = block.getMetadata("Blocks");
            if(!value.isEmpty()) {
                Explosive explosive = (Explosive) value.get(0).value();
                if(explosive.getBlockToBreak().isEmpty()) {
                    event.blockList().clear();
                    return;
                }
                List<Block> blockToBreak = this.getNearbyBlocks(block.getLocation(), (int)explosive.getRadius()+2);
                event.blockList().removeIf(toBroken -> blockToBreak.contains(toBroken) && !explosive.getBlockToBreak().contains(toBroken.getType()));
                block.setType(Material.AIR);
            }
        }

        if(event.getEntity().hasMetadata("Explosive")) {
            event.blockList().clear();
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if(event.getCause() == EntityDamageEvent.DamageCause.PROJECTILE && event.getDamager() instanceof Projectile) {
            Projectile projectile = (Projectile) event.getDamager();
            if(projectile.hasMetadata("Projectile")) {
                List<MetadataValue> value = projectile.getMetadata("Projectile");
                if(!value.isEmpty()) {
                    Guns guns = (Guns) value.get(0).value();
                    if (guns != null && event.getEntity() instanceof LivingEntity) {
                        LivingEntity damaged = (LivingEntity) event.getEntity();
                        double damage;
                        double projectileY = event.getEntity().getLocation().getY();
                        double damagedY = damaged.getLocation().getY();
                        if (projectileY - damagedY > 1.35) {
                            damage = guns.getHeadshotDamage();
                        } else {
                            damage = guns.getNormalDamage();
                        }

                        if (damaged instanceof Player) {
                            Player playerDamaged = (Player) damaged;
                            for (ItemStack itemStack : playerDamaged.getInventory().getArmorContents()) {
                                if (itemStack != null && itemStack.getType() != Material.AIR) {
                                    NBTItem nbtItem = new NBTItem(itemStack);
                                    if (nbtItem.hasKey("CustomArmor") && nbtItem.getBoolean("CustomArmor")) {
                                        Armor armor = Main.getWeaponManager().getArmor(nbtItem.getString("Armor"));
                                        if (armor != null) {
                                            if (armor.getDiscountType() == DiscountType.AMOUNT) {
                                                damage -= nbtItem.getDouble("Protection");
                                            } else if (armor.getDiscountType() == DiscountType.PERCENTAGE) {
                                                damage -= (damage * (nbtItem.getDouble("Protection") / 100));
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        event.setDamage(damage);
                        damaged.setNoDamageTicks(0);
                    }
                }
            }
            if(projectile.hasMetadata("Explosive")) {
                event.setDamage(1.0);
            }
        }
        if(event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            ItemStack helmet = player.getInventory().getHelmet();
            if(helmet != null && helmet.getType() != Material.AIR) {
                NBTItem nbtItem = new NBTItem(helmet);
                if(nbtItem.hasKey("CustomArmor") && nbtItem.getBoolean("CustomArmor")) {
                    nbtItem.setInteger("Durability", nbtItem.getInteger("Durability")-1);

                    if(nbtItem.getInteger("Durability") <= 0) {
                        player.getInventory().setHelmet(null);
                        if(Utils.is1_8()) {
                            player.playSound(player.getLocation(), Sound.valueOf("ITEM_BREAK"), 1.0f, 1.0f);
                        } else {
                            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
                        }
                    } else {
                        player.getInventory().setHelmet(nbtItem.getItem());
                    }
                }
            }

            ItemStack chestplate = player.getInventory().getChestplate();
            if(chestplate != null && chestplate.getType() != Material.AIR) {
                NBTItem nbtItem = new NBTItem(chestplate);
                if(nbtItem.hasKey("CustomArmor") && nbtItem.getBoolean("CustomArmor")) {
                    nbtItem.setInteger("Durability", nbtItem.getInteger("Durability")-1);

                    if(nbtItem.getInteger("Durability") <= 0) {
                        player.getInventory().setChestplate(null);
                        if(Utils.is1_8()) {
                            player.playSound(player.getLocation(), Sound.valueOf("ITEM_BREAK"), 1.0f, 1.0f);
                        } else {
                            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
                        }
                    } else {
                        player.getInventory().setChestplate(nbtItem.getItem());
                    }
                }
            }

            ItemStack leggings = player.getInventory().getLeggings();
            if(leggings != null && leggings.getType() != Material.AIR) {
                NBTItem nbtItem = new NBTItem(leggings);
                if(nbtItem.hasKey("CustomArmor") && nbtItem.getBoolean("CustomArmor")) {
                    nbtItem.setInteger("Durability", nbtItem.getInteger("Durability")-1);

                    if(nbtItem.getInteger("Durability") <= 0) {
                        player.getInventory().setChestplate(null);
                        if(Utils.is1_8()) {
                            player.playSound(player.getLocation(), Sound.valueOf("ITEM_BREAK"), 1.0f, 1.0f);
                        } else {
                            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
                        }
                    } else {
                        player.getInventory().setChestplate(nbtItem.getItem());
                    }
                }
            }

            ItemStack boots = player.getInventory().getBoots();
            if(boots != null && boots.getType() != Material.AIR) {
                NBTItem nbtItem = new NBTItem(boots);
                if(nbtItem.hasKey("CustomArmor") && nbtItem.getBoolean("CustomArmor")) {
                    nbtItem.setInteger("Durability", nbtItem.getInteger("Durability")-1);

                    if(nbtItem.getInteger("Durability") <= 0) {
                        player.getInventory().setBoots(null);
                        if(Utils.is1_8()) {
                            player.playSound(player.getLocation(), Sound.valueOf("ITEM_BREAK"), 1.0f, 1.0f);
                        } else {
                            player.playSound(player.getLocation(), Sound.ENTITY_ITEM_BREAK, 1.0f, 1.0f);
                        }
                    } else {
                        player.getInventory().setBoots(nbtItem.getItem());
                    }
                }
            }
        }
    }

    @EventHandler
    public void onHit(ProjectileHitEvent event) {
        if(event.getEntity().getShooter() != null && event.getEntity().getShooter() instanceof Player) {
            Player player = (Player) event.getEntity().getShooter();
            if(event.getEntity().hasMetadata("Explosive")) {
                Location loc = event.getEntity().getLocation();
                loc.getWorld().playEffect(loc, Effect.EXPLOSION, 5);
                loc.getWorld().playEffect(loc, Effect.EXPLOSION_HUGE, 5);
                loc.getWorld().playEffect(loc, Effect.EXPLOSION_LARGE, 5);
                if(Utils.is1_8()) {
                    loc.getWorld().playSound(loc, Sound.valueOf("EXPLODE"), 3.0f, 1.0f);
                } else {
                    loc.getWorld().playSound(loc, Sound.ENTITY_GENERIC_EXPLODE, 3.0f, 1.0f);
                }
                for(Entity entity : event.getEntity().getNearbyEntities(4.0, 4.0, 4.0)) {
                    if(entity instanceof LivingEntity) {
                        LivingEntity livingEntity = (LivingEntity) entity;
                        livingEntity.damage(3.0, player);
                    }
                }
                event.getEntity().remove();
            }
        }
    }

    @EventHandler
    public void onSlotChange(PlayerItemHeldEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItem(event.getPreviousSlot());
        if(item != null && item.getType() != Material.AIR) {
            NBTItem nbtItem = new NBTItem(item);
            if (nbtItem.hasKey("Weapon") && nbtItem.getBoolean("Weapon") && nbtItem.hasKey("WeaponType")) {
                if(nbtItem.getBoolean("Scope")) {
                    player.removePotionEffect(PotionEffectType.SLOW);
                    nbtItem.setBoolean("Scope", false);

                    player.getInventory().setItem(this.getItemSlot(player, nbtItem.getItem()), nbtItem.getItem());
                }
            }
        }
    }

    public boolean shootGun(Player player, Guns guns, NBTItem nbtItem, FireType fireType) {
        guns.getShootDelayList().remove(player.getUniqueId());
        if(nbtItem.getBoolean("Reloading")) {
            return false;
        }
        if(!nbtItem.getBoolean("Armed")) {
            player.getWorld().playSound(player.getLocation(), guns.getNoBulletsSound().getSound(), guns.getNoBulletsSound().getVolume(), 1f);
            if(guns.isAutomaticReload() && !nbtItem.getBoolean("Reloading")) {
                this.reloadGun(player, guns, nbtItem);
            }
            return false;
        }

        if(nbtItem.getInteger("CurrentAmount") <= 0) {
            nbtItem.setBoolean("Armed", false);
            player.getWorld().playSound(player.getLocation(), guns.getNoBulletsSound().getSound(), guns.getNoBulletsSound().getVolume(), 1f);
            if(guns.isAutomaticReload() && !nbtItem.getBoolean("Reloading")) {
                this.reloadGun(player, guns, nbtItem);
            }
            return false;
        }
        guns.getShootDelayList().put(player.getUniqueId(), System.currentTimeMillis());

        this.WRAPPER.sendPacketPlayOutPosition(player, (float)randomInt(-guns.getRecoil(), guns.getRecoil()), (float)(-randomInt(0.0, guns.getRecoil())));

        if(fireType == FireType.BURST && guns.getGunType() != GunType.EXPLOSIVE) {
            new BukkitRunnable() {
                int count = guns.getProjectileAmount();
                @Override
                public void run() {
                    if(count <= 0 || !Listeners.this.shootGun(player, guns, nbtItem, FireType.SEMIAUTOMATIC)) {
                        this.cancel();
                        return;
                    }
                    count--;
                }
            }.runTaskTimer(Main.getInstance(), 0L, TimeUnit.MILLISECONDS.toSeconds((guns.getShootDelay()/guns.getProjectileAmount())) * 3L);
        } else {
            player.getWorld().playSound(player.getLocation(), guns.getShootingSound().getSound(), guns.getShootingSound().getVolume(), 1f);
            nbtItem.setInteger("CurrentAmount", nbtItem.getInteger("CurrentAmount") - 1);
            Vector vector = player.getLocation().getDirection().multiply(guns.getVelocity()).normalize();
            Snowball snow = player.launchProjectile(Snowball.class);
            snow.setBounce(guns.isBounce());
            snow.setShooter(player);
            snow.setVelocity(vector);
            snow.setMetadata("Projectile", new FixedMetadataValue(Main.getInstance(), guns));
            if (guns.getGunType() == GunType.EXPLOSIVE) {
                snow.setMetadata("Explosive", new FixedMetadataValue(Main.getInstance(), true));
            }
        }

        Utils.sendActionbar(player, Main.Color(ConfigManager.getSettings().getString("Messages.WeaponStatus").replace("%weapon%", guns.getName()).replace("%maxcapacity%", String.valueOf(guns.getAmmoCapacity())).replace("%currentamount%", String.valueOf(nbtItem.getInteger("CurrentAmount")))));
        player.setItemInHand(nbtItem.getItem());

        if(nbtItem.getInteger("CurrentAmount") <= 0) {
            nbtItem.setBoolean("Armed", false);
            if(guns.isAutomaticReload() && !nbtItem.getBoolean("Reloading")) {
                this.reloadGun(player, guns, nbtItem);
            }
        }
        return true;
    }

    public static double randomInt(double low, double high) {
        return Math.random() * (high - low) + low;
    }

    public boolean reloadGun(Player player, Guns guns, NBTItem nbtItem) {
        ItemStack item = this.getAmmo(player, guns);
        if((item != null && nbtItem.getInteger("CurrentAmount") < guns.getAmmoCapacity()) && item.getAmount() >= 1) {
            nbtItem.setBoolean("Reloading", true);
            player.setItemInHand(nbtItem.getItem());

            int ammoCount = guns.getAmmoCapacity() - nbtItem.getInteger("CurrentAmount");
            if(item.getAmount() > ammoCount) {
                nbtItem.setInteger("CurrentAmount", nbtItem.getInteger("CurrentAmount") + ammoCount);
                item.setAmount(item.getAmount()-ammoCount);
            } else {
                nbtItem.setInteger("CurrentAmount", nbtItem.getInteger("CurrentAmount") + item.getAmount());
                player.getInventory().remove(item);
            }
            nbtItem.setBoolean("Armed", true);
            player.updateInventory();

            new BukkitRunnable() {
                double count = 0.0;
                @Override
                public void run() {
                    if(nbtItem.getItem() == null || Listeners.this.getItemSlot(player, nbtItem.getItem()) == -1) {
                        this.cancel();
                        return;
                    }
                    if(count >= TimeUnit.MILLISECONDS.toSeconds(guns.getReloadDelay())) {
                        nbtItem.setBoolean("Reloading", false);
                        Utils.sendActionbar(player, Main.Color(ConfigManager.getSettings().getString("Messages.WeaponReloaded").replace("%weapon%", guns.getName())));
                        player.getInventory().setItem(Listeners.this.getItemSlot(player, nbtItem.getItem()), nbtItem.getItem());
                        this.cancel();
                        return;
                    }
                    Utils.sendActionbar(player, Main.Color(ConfigManager.getSettings().getString("Messages.ReloadingWeapon").replace("%weapon%", guns.getName())));
                    player.getWorld().playSound(player.getLocation(), guns.getReloadingSound().getSound(), guns.getReloadingSound().getVolume(), 1f);
                    count += 0.5;
                }
            }.runTaskTimer(Main.getInstance(), 0L, 10L);
            return true;
        }
        Utils.sendActionbar(player, Main.Color(ConfigManager.getSettings().getString("Messages.NoBullets").replace("%weapon%", guns.getName())));
        return false;
    }

    public ItemStack getAmmo(Player player, Guns guns) {
        for(int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && item.getType() != Material.AIR) {
                NBTItem ammoNbt = new NBTItem(item);
                if(ammoNbt.hasKey("AmmoType") && ammoNbt.getString("AmmoType").equalsIgnoreCase(guns.getName())) {
                    return item;
                }
            }
        }
        return null;
    }

    public int getItemSlot(Player player, ItemStack itemStack) {
        for(int i = 0; i < player.getInventory().getSize(); i++) {
            ItemStack item = player.getInventory().getItem(i);
            if (item != null && item.getType() != Material.AIR) {
                NBTItem nbtItem = new NBTItem(item);
                NBTItem nbtItem2 = new NBTItem(itemStack);
                if(nbtItem.hasKey("UUID") && nbtItem2.hasKey("UUID") && nbtItem.getString("UUID").equalsIgnoreCase(nbtItem2.getString("UUID"))) {
                    return i;
                }
            }
        }
        return -1;
    }
}
