package com.gabrielhd.guns.Enums;

public enum GunType {

    IMPACT,
    EXPLOSIVE
}
