package com.gabrielhd.guns.Enums;

public enum ExplosiveType {

    THROWING,
    STATIC
}
