package com.gabrielhd.guns.Enums;

public enum FireType {

    BURST,
    AUTOMATIC,
    SEMIAUTOMATIC,
}
