package com.gabrielhd.guns.Enums;

public enum DiscountType {

    AMOUNT,
    PERCENTAGE
}
