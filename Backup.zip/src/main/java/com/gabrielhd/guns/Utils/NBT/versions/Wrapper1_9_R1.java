package com.gabrielhd.guns.Utils.NBT.versions;

import com.gabrielhd.guns.Utils.NBT.VersionWrapper;
import net.minecraft.server.v1_9_R1.ChatComponentText;
import net.minecraft.server.v1_9_R1.PacketPlayOutChat;
import net.minecraft.server.v1_9_R1.NBTTagCompound;
import net.minecraft.server.v1_9_R1.PacketPlayOutPosition;
import org.bukkit.craftbukkit.v1_9_R1.entity.CraftPlayer;
import org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class Wrapper1_9_R1 implements VersionWrapper {

    private final Set<PacketPlayOutPosition.EnumPlayerTeleportFlags> teleportFlags  = new HashSet<>(Arrays.asList(PacketPlayOutPosition.EnumPlayerTeleportFlags.X_ROT, PacketPlayOutPosition.EnumPlayerTeleportFlags.Y_ROT, PacketPlayOutPosition.EnumPlayerTeleportFlags.X, PacketPlayOutPosition.EnumPlayerTeleportFlags.Y, PacketPlayOutPosition.EnumPlayerTeleportFlags.Z));

    @Override
    public void sendActionText(Player player, String message) {
        PacketPlayOutChat packet = new PacketPlayOutChat(new ChatComponentText(message), (byte)2);
        ((CraftPlayer) player).getHandle().playerConnection.sendPacket(packet);
    }

    @Override
    public void sendPacketPlayOutPosition(Player player, float yaw, float pitch) {
        PacketPlayOutPosition packet = new PacketPlayOutPosition(0.0, 0.0, 0.0, yaw, pitch, this.teleportFlags, 0);
        ((CraftPlayer)player).getHandle().playerConnection.sendPacket(packet);
    }

    @Override
    public boolean hasKey(ItemStack item, String s) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        return stack.getTag().hasKey(s);
    }

    @Override
    public String getString(ItemStack item, String s) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        return stack.getTag().getString(s);
    }

    @Override
    public ItemStack setString(ItemStack item, String s1, String s2) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        stack.getTag().setString(s1, s2);
        return org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asCraftMirror(stack);
    }

    @Override
    public double getDouble(ItemStack item, String s) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        return stack.getTag().getDouble(s);
    }

    @Override
    public ItemStack setDouble(ItemStack item, String s1, double d1) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        stack.getTag().setDouble(s1, d1);
        return org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asCraftMirror(stack);
    }

    @Override
    public int getInteger(ItemStack item, String s) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        return stack.getTag().getInt(s);
    }

    @Override
    public ItemStack setInteger(ItemStack item, String s1, int i1) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        stack.getTag().setInt(s1, i1);
        return org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asCraftMirror(stack);
    }

    @Override
    public boolean getBoolean(ItemStack item, String s) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new net.minecraft.server.v1_9_R1.NBTTagCompound());
        return stack.getTag().getBoolean(s);
    }

    @Override
    public ItemStack setBoolean(ItemStack item, String s1, boolean b1) {
        net.minecraft.server.v1_9_R1.ItemStack stack = org.bukkit.craftbukkit.v1_9_R1.inventory.CraftItemStack.asNMSCopy(item);
        if (stack.getTag() == null) stack.setTag(new NBTTagCompound());
        stack.getTag().setBoolean(s1, b1);
        return CraftItemStack.asCraftMirror(stack);
    }
}